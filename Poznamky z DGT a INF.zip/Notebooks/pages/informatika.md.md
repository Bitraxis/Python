# John Von Neumannova sústava
	- ## Klasifikácia technického vybavenia počítača:
		-