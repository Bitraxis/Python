print("Absolútna hodnota čísla a:")
a = int(input("a: "))
if a>0 :
    print(a * 1)
else:
    print(a * -1)