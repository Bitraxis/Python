import math
print ("Obvod kruhu")
r = float(input("r: "))
O = 2 * math.pi * r
print("Obvod takého kruhu je " + str(O))

